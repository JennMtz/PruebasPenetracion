﻿$Listener = [System.Net.Sockets.TcpListener]9999;
$Listener.Start();